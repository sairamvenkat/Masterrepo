﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace SampleConsoleApp
//{
//    class SendSMSfromTwilio
//    {
//    }
//}
// Install the C# / .NET helper library from twilio.com/docs/csharp/install

using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;


class SendMessageFromTwilio
{
    ////Poornima Vadina Tokens
    const string accountSid = "ACcf6b0f4ac239c4958e9567b8a31d45bb";
    const string authToken = "4d63904c23c5c632a30f923338f1bab7";

    //Sai Tokens
    //const string accountSid = "ACcf6b0f4ac239c4958e9567b8a31d45bb";
    //const string authToken = "4d63904c23c5c632a30f923338f1bab7";
    static void Main(string[] args)
    {
        SendMessageFromTwilio msg = new SendMessageFromTwilio();
        // msg. sendTextMessage();
        msg.sendWhatsAppMessage();
        //msg.UpdateMessage();
        //msg.ReadMessages();
        //msg.sendTextMessage_India();
    }
    private void sendWhatsAppMessage()
    {
        TwilioClient.Init(accountSid, authToken);

        var message = MessageResource.Create(
            body: "Hello there!",
            from: new Twilio.Types.PhoneNumber("whatsapp:+14155238886 "),
            to: new Twilio.Types.PhoneNumber("whatsapp:+917416037183")
        );

        Console.WriteLine(message.Sid);
    }
    private void sendTextMessage()
    {


        TwilioClient.Init(accountSid, authToken);

        var message = MessageResource.Create(
            from: new Twilio.Types.PhoneNumber("+12692253862"),
            body: "Message from Twilio",
            to: new Twilio.Types.PhoneNumber("+12692675079")
        );

        Console.WriteLine(message.Sid);
    }

    private void sendTextMessage_India()
    {


        TwilioClient.Init(accountSid, authToken);

        var message = MessageResource.Create(
            from: new Twilio.Types.PhoneNumber("+917416037183"),
            body: "Message from Twilio",
            to: new Twilio.Types.PhoneNumber("+919032842466")
        );

        Console.WriteLine(message.Sid);
    }
    private void ReadMessages()
    {

        TwilioClient.Init(accountSid, authToken);

        var messages = MessageResource.Read();

        foreach (var record in messages)
        {
            Console.WriteLine(record.Sid + "--" + record.Body);
        }
    }
    private void UpdateMessage()
    {
        TwilioClient.Init(accountSid, authToken);
        var message = MessageResource.Update(
            body: "Updated Message from Twilio",
            pathSid: "SM1bfc6ff96de1436db244059d98d83f42"
        );

        Console.WriteLine(message.To);
    }
}

