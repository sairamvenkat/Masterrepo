﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WhatsAppApi;

namespace SampleConsoleApp
{
    class SendWhatsAppFromCsharp
    {
        //static void Main(string[] args)
        //{
        //    SendWhatsAppFromCsharp msg = new SendWhatsAppFromCsharp();
        //    msg.SendMessage("+917995548663","sample Test Whatsapp message");
        //}
        public void SendMessage(string sendTo, string message)
        {
            var response = false;
            string from = "7416037183"; //(Enter Your Mobile Number)
            String password;
            var res = WhatsAppApi.Register.WhatsRegisterV2.RequestCode(from, out password);
            WhatsApp wa = new WhatsApp(from, password, "abc.com", false, false);
            wa.OnConnectSuccess += () =>
            {
                wa.OnLoginSuccess += (phonenumber, data) =>
                {
                    wa.SendMessage(sendTo, message);
                    response = true;
                };
                wa.OnLoginFailed += (data) =>
                {
                    response = false;
                };

                wa.Login();
            };
            wa.OnConnectFailed += (Exception) =>
            {
                response = false;
            };
           // return Json(response);
        }
    }
}



